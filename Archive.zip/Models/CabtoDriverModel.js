module.exports = (sequelize, DataTypes) => {
    const CabtoDriver = sequelize.define("CabtoDriver", {
      vehicleid: { type: DataTypes.STRING(36), primaryKey: true },
      driverid: DataTypes.STRING(36),
      timestamp: DataTypes.DATE,
    });
    return CabtoDriver;
  };
  