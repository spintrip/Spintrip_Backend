module.exports = (sequelize, DataTypes) => {
    const CabBookingRequest = sequelize.define("CabBookingRequest", {
      Bookingid: { type: DataTypes.STRING(36), primaryKey: true },
      Date: DataTypes.DATEONLY,
      vehicleid: { type: DataTypes.STRING(36)},   
      time: DataTypes.DATE,
      timestamp: DataTypes.DATE,
      id: {type: DataTypes.STRING(36)},
      status: { type: DataTypes.INTEGER,allowNull: true },
      amount: { type: DataTypes.FLOAT, allowNull: true },
      GSTAmount: { type: DataTypes.FLOAT, allowNull: true }, 
      totalUserAmount: { type: DataTypes.FLOAT, allowNull: true },
      Transactionid: { type: DataTypes.STRING, unique: true },
      startTripDate: { type: DataTypes.DATEONLY, allowNull: true },
      endTripDate: { type: DataTypes.DATEONLY, allowNull: true },
      startTripTime: { type: DataTypes.TIME, allowNull: true },
      endTripTime: { type: DataTypes.TIME, allowNull: true },
      cancelDate: { type: DataTypes.DATE, allowNull: true },
      cancelReason: { type: DataTypes.TEXT, allowNull: true },
      startLocationLatitude: DataTypes.FLOAT,
      startLocationLongitude: DataTypes.FLOAT,
      endLocationLatitude: DataTypes.FLOAT,
      endLocationLongitude: DataTypes.FLOAT,
      estimate_price: DataTypes.FLOAT,
      estimate_time: DataTypes.FLOAT,
      otp: DataTypes.INTEGER,


    });
  
    CabBookingRequest.associate = (models) => {
        CabBookingRequest.belongsTo(models.Vehicle, { foreignKey: 'vehicleid' });
    };
  
    return Booking;
  };