module.exports = (sequelize, DataTypes) => {
  const Listing = sequelize.define("Driver", {
    id: {
      type: DataTypes.STRING(36),
      primaryKey: true,
    },
    hostid: {
      type: DataTypes.STRING(36),
    },
    details: {
      type: DataTypes.STRING,
    },
    pausetime_start_date: {
      type: DataTypes.DATEONLY,
      allowNull: true,
    },
    pausetime_end_date: {
      type: DataTypes.DATEONLY,
      allowNull: true,
    },
    pausetime_start_time: {
      type: DataTypes.TIME,
      allowNull: true,
    },
    pausetime_end_time: {
      type: DataTypes.TIME,
      allowNull: true,
    }
    
  });


  return Driver;
};
